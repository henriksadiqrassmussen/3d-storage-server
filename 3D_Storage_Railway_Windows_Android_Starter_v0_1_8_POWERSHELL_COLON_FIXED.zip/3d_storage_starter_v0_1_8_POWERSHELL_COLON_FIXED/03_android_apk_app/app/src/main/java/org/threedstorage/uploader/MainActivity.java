package org.threedstorage.uploader;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final int PICK_FILE = 2001;
    private EditText serverInput;
    private TextView fileText;
    private TextView logText;
    private Uri selectedUri;
    private String selectedName = "file.bin";
    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("settings", MODE_PRIVATE);
        buildUi();
    }

    private void buildUi() {
        int bg = Color.rgb(13, 17, 23);
        int panel = Color.rgb(21, 27, 36);
        int text = Color.rgb(244, 247, 251);
        int muted = Color.rgb(169, 180, 196);
        int accent = Color.rgb(255, 159, 28);

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(bg);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(22), dp(18), dp(22));
        scroll.addView(root);

        TextView badge = label("3d-storage.org", accent, 14, true);
        root.addView(badge);

        TextView title = label("3D Storage Upload", text, 28, true);
        title.setPadding(0, dp(10), 0, dp(4));
        root.addView(title);

        TextView intro = label("Send FBX, GLB, GLTF eller ZIP fra telefonen til Railway-serveren. Windows-programmet kan derefter hente filerne.", muted, 16, false);
        intro.setPadding(0, 0, 0, dp(18));
        root.addView(intro);

        LinearLayout card1 = card(panel);
        card1.addView(label("Server URL", text, 17, true));
        serverInput = new EditText(this);
        serverInput.setText(prefs.getString("serverUrl", "https://dit-projekt.up.railway.app"));
        serverInput.setSingleLine(true);
        serverInput.setTextColor(text);
        serverInput.setHintTextColor(muted);
        serverInput.setTextSize(15);
        serverInput.setPadding(dp(12), dp(10), dp(12), dp(10));
        serverInput.setBackgroundColor(Color.rgb(11, 15, 21));
        card1.addView(serverInput, new LinearLayout.LayoutParams(-1, dp(52)));
        Button test = button("Test server", accent);
        test.setOnClickListener(v -> testServer());
        card1.addView(test);
        root.addView(card1);

        LinearLayout card2 = card(panel);
        card2.addView(label("Fil", text, 17, true));
        fileText = label("Ingen fil valgt", muted, 15, false);
        fileText.setPadding(0, dp(8), 0, dp(12));
        card2.addView(fileText);
        Button pick = button("Vælg FBX / GLB / ZIP", accent);
        pick.setOnClickListener(v -> pickFile());
        card2.addView(pick);
        Button upload = button("Upload til 3D Storage", accent);
        upload.setOnClickListener(v -> uploadSelected());
        card2.addView(upload);
        root.addView(card2);

        LinearLayout card3 = card(panel);
        card3.addView(label("Log", text, 17, true));
        logText = label("Klar. Test serveren først.\n", muted, 14, false);
        logText.setPadding(0, dp(8), 0, 0);
        card3.addView(logText);
        root.addView(card3);

        setContentView(scroll);
    }

    private LinearLayout card(int color) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(16), dp(16), dp(16), dp(16));
        c.setBackgroundColor(color);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 0, 0, dp(16));
        c.setLayoutParams(lp);
        return c;
    }

    private TextView label(String s, int color, int size, boolean bold) {
        TextView v = new TextView(this);
        v.setText(s);
        v.setTextColor(color);
        v.setTextSize(size);
        if (bold) v.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        v.setLineSpacing(dp(2), 1.0f);
        return v;
    }

    private Button button(String s, int color) {
        Button b = new Button(this);
        b.setText(s);
        b.setTextColor(Color.rgb(16, 17, 19));
        b.setTextSize(15);
        b.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        b.setAllCaps(false);
        b.setGravity(Gravity.CENTER);
        b.setBackgroundColor(color);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(54));
        lp.setMargins(0, dp(10), 0, 0);
        b.setLayoutParams(lp);
        return b;
    }

    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    private String baseUrl() {
        String s = serverInput.getText().toString().trim();
        while (s.endsWith("/")) s = s.substring(0, s.length()-1);
        prefs.edit().putString("serverUrl", s).apply();
        return s;
    }

    private void log(String s) {
        runOnUiThread(() -> logText.setText("[" + new java.text.SimpleDateFormat("HH:mm:ss").format(new java.util.Date()) + "] " + s + "\n" + logText.getText()));
    }

    private void testServer() {
        new Thread(() -> {
            try {
                URL url = new URL(baseUrl() + "/health");
                HttpURLConnection c = (HttpURLConnection) url.openConnection();
                c.setConnectTimeout(10000);
                c.setReadTimeout(10000);
                c.setRequestMethod("GET");
                int code = c.getResponseCode();
                String body = readAll(c.getInputStream());
                log("Server OK HTTP " + code + ": " + body);
            } catch (Exception e) {
                log("Server test fejl: " + e.getMessage());
            }
        }).start();
    }

    private void pickFile() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
                "application/octet-stream", "model/gltf-binary", "model/gltf+json", "application/zip", "application/x-zip-compressed"
        });
        startActivityForResult(intent, PICK_FILE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_FILE && resultCode == RESULT_OK && data != null) {
            selectedUri = data.getData();
            getContentResolver().takePersistableUriPermission(selectedUri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            selectedName = getFileName(selectedUri);
            fileText.setText(selectedName + "\n" + selectedUri.toString());
            log("Valgt fil: " + selectedName);
        }
    }

    private String getFileName(Uri uri) {
        try (Cursor cursor = getContentResolver().query(uri, null, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (idx >= 0) return cursor.getString(idx);
            }
        } catch (Exception ignored) {}
        return "upload.bin";
    }

    private void uploadSelected() {
        if (selectedUri == null) {
            Toast.makeText(this, "Vælg en fil først", Toast.LENGTH_SHORT).show();
            return;
        }
        new Thread(() -> {
            try {
                log("Uploader " + selectedName + "...");
                String boundary = "----3DStorage" + System.currentTimeMillis();
                URL url = new URL(baseUrl() + "/api/upload");
                HttpURLConnection c = (HttpURLConnection) url.openConnection();
                c.setConnectTimeout(20000);
                c.setReadTimeout(120000);
                c.setDoOutput(true);
                c.setRequestMethod("POST");
                c.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + boundary);

                DataOutputStream out = new DataOutputStream(c.getOutputStream());
                out.writeBytes("--" + boundary + "\r\n");
                out.writeBytes("Content-Disposition: form-data; name=\"file\"; filename=\"" + selectedName.replace("\"", "_") + "\"\r\n");
                out.writeBytes("Content-Type: application/octet-stream\r\n\r\n");

                try (InputStream in = new BufferedInputStream(getContentResolver().openInputStream(selectedUri))) {
                    byte[] buffer = new byte[64 * 1024];
                    int n;
                    while ((n = in.read(buffer)) > 0) out.write(buffer, 0, n);
                }

                out.writeBytes("\r\n--" + boundary + "--\r\n");
                out.flush();
                out.close();

                int code = c.getResponseCode();
                InputStream responseStream = code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream();
                String body = readAll(responseStream);
                log("Upload svar HTTP " + code + ": " + body);
            } catch (Exception e) {
                log("Upload fejl: " + e.getMessage());
            }
        }).start();
    }

    private String readAll(InputStream in) throws Exception {
        if (in == null) return "";
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        byte[] b = new byte[8192];
        int n;
        while ((n = in.read(b)) > 0) bos.write(b, 0, n);
        return bos.toString(StandardCharsets.UTF_8.name());
    }
}
