@echo off
chcp 65001 >nul
cd /d "%~dp0"
set LOG=%~dp0windows_app_super_simple_log.txt
echo 3D Storage PC Companion - super simple diagnose > "%LOG%"
echo Date: %DATE% %TIME% >> "%LOG%"
echo Folder: %CD% >> "%LOG%"
echo. >> "%LOG%"
echo where powershell: >> "%LOG%"
where powershell >> "%LOG%" 2>&1
echo. >> "%LOG%"
echo where node: >> "%LOG%"
where node >> "%LOG%" 2>&1
echo. >> "%LOG%"
echo node -v: >> "%LOG%"
node -v >> "%LOG%" 2>&1
echo. >> "%LOG%"
echo where npm: >> "%LOG%"
where npm >> "%LOG%" 2>&1
echo. >> "%LOG%"
echo npm -v: >> "%LOG%"
npm -v >> "%LOG%" 2>&1
echo. >> "%LOG%"
echo package.json: >> "%LOG%"
if exist package.json (echo package.json findes >> "%LOG%") else (echo package.json MANGLER >> "%LOG%")
echo.
echo Log gemt som:
echo %LOG%
echo.
type "%LOG%"
echo.
pause
