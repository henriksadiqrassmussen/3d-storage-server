Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$form = New-Object System.Windows.Forms.Form
$form.Text = '3D Storage PC Companion Lite'
$form.Size = New-Object System.Drawing.Size(760,560)
$form.StartPosition = 'CenterScreen'
$form.BackColor = [System.Drawing.Color]::FromArgb(16,19,25)
$form.ForeColor = [System.Drawing.Color]::White
$form.Font = New-Object System.Drawing.Font('Segoe UI',10)

function New-Label($text,$x,$y,$w,$h){
    $l=New-Object System.Windows.Forms.Label
    $l.Text=$text; $l.Location=New-Object System.Drawing.Point($x,$y); $l.Size=New-Object System.Drawing.Size($w,$h)
    $l.ForeColor=[System.Drawing.Color]::White
    return $l
}
function New-Button($text,$x,$y,$w,$h){
    $b=New-Object System.Windows.Forms.Button
    $b.Text=$text; $b.Location=New-Object System.Drawing.Point($x,$y); $b.Size=New-Object System.Drawing.Size($w,$h)
    $b.BackColor=[System.Drawing.Color]::FromArgb(255,159,28); $b.ForeColor=[System.Drawing.Color]::Black
    $b.FlatStyle='Flat'
    return $b
}
function Log($msg){
    $time=(Get-Date).ToString('HH:mm:ss')
    $log.AppendText("[$time] $msg`r`n")
}

$title=New-Label '3D Storage PC Companion Lite' 22 18 520 34
$title.Font=New-Object System.Drawing.Font('Segoe UI',18,[System.Drawing.FontStyle]::Bold)
$title.ForeColor=[System.Drawing.Color]::FromArgb(255,159,28)
$form.Controls.Add($title)

$form.Controls.Add((New-Label 'Server URL / Railway URL:' 24 72 210 24))
$urlBox=New-Object System.Windows.Forms.TextBox
$urlBox.Location=New-Object System.Drawing.Point(24,100); $urlBox.Size=New-Object System.Drawing.Size(500,30)
$urlBox.Text='http://localhost:3000'
$form.Controls.Add($urlBox)

$testBtn=New-Button 'Test forbindelse' 540 98 170 34
$form.Controls.Add($testBtn)

$fileLabel=New-Label 'Ingen fil valgt' 24 150 680 24
$fileLabel.ForeColor=[System.Drawing.Color]::Gainsboro
$form.Controls.Add($fileLabel)

$pickBtn=New-Button 'Vælg FBX / GLB / ZIP' 24 180 210 38
$uploadBtn=New-Button 'Upload til server' 248 180 180 38
$listBtn=New-Button 'Hent filliste' 442 180 150 38
$openBtn=New-Button 'Åbn download-mappe' 24 230 210 38
$form.Controls.Add($pickBtn); $form.Controls.Add($uploadBtn); $form.Controls.Add($listBtn); $form.Controls.Add($openBtn)

$downloadDir=Join-Path $PSScriptRoot 'downloads'
New-Item -ItemType Directory -Force -Path $downloadDir | Out-Null

$selectedFile=$null
$openDlg=New-Object System.Windows.Forms.OpenFileDialog
$openDlg.Filter='3D filer og ZIP|*.fbx;*.glb;*.gltf;*.zip|Alle filer|*.*'
$openDlg.Multiselect=$false

$log=New-Object System.Windows.Forms.TextBox
$log.Location=New-Object System.Drawing.Point(24,288); $log.Size=New-Object System.Drawing.Size(686,210)
$log.Multiline=$true; $log.ScrollBars='Vertical'; $log.ReadOnly=$true
$log.BackColor=[System.Drawing.Color]::FromArgb(11,14,19); $log.ForeColor=[System.Drawing.Color]::White
$form.Controls.Add($log)

$pickBtn.Add_Click({
    if($openDlg.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK){
        $script:selectedFile=$openDlg.FileName
        $fileLabel.Text='Valgt fil: ' + $script:selectedFile
        Log('Fil valgt: ' + $script:selectedFile)
    }
})

$testBtn.Add_Click({
    try{
        $base=$urlBox.Text.Trim().TrimEnd('/')
        Log('Tester: ' + $base + '/health')
        $r=Invoke-RestMethod -Uri ($base + '/health') -Method Get -TimeoutSec 15
        if($r.ok){ Log('OK: Server svarer. Version: ' + $r.version) } else { Log('Server svarede, men ok=false') }
    } catch { Log('FEJL ved test: ' + $_.Exception.Message) }
})

$uploadBtn.Add_Click({
    if(-not $script:selectedFile -or -not (Test-Path $script:selectedFile)){ Log('Vælg en fil først.'); return }
    try{
        $base=$urlBox.Text.Trim().TrimEnd('/')
        Log('Uploader til: ' + $base + '/api/upload')
        $formData=@{ file = Get-Item $script:selectedFile }
        $r=Invoke-RestMethod -Uri ($base + '/api/upload') -Method Post -Form $formData -TimeoutSec 120
        if($r.ok){ Log('UPLOAD OK: ' + $r.file.storedName) } else { Log('Upload svarede ikke OK') }
    } catch { Log('FEJL ved upload: ' + $_.Exception.Message) }
})

$listBtn.Add_Click({
    try{
        $base=$urlBox.Text.Trim().TrimEnd('/')
        Log('Henter filliste...')
        $r=Invoke-RestMethod -Uri ($base + '/api/files') -Method Get -TimeoutSec 30
        Log('Filer på server: ' + $r.count)
        foreach($f in $r.files){ Log(' - ' + $f.name + ' (' + $f.size + ' bytes)') }
    } catch { Log('FEJL ved filliste: ' + $_.Exception.Message) }
})

$openBtn.Add_Click({
    Start-Process explorer.exe $downloadDir
})

Log('Klar. Denne version bruger Windows PowerShell og kræver ikke Electron/npm.')
Log('Skriv Railway URL eller brug http://localhost:3000 ved lokal server.')
[void]$form.ShowDialog()
