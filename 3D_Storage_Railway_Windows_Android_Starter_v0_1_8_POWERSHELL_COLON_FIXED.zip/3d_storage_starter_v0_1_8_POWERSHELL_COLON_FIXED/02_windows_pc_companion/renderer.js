const $ = (id) => document.getElementById(id);
let selectedFile = null;

const serverUrl = $('serverUrl');
const saved = localStorage.getItem('serverUrl');
if (saved) serverUrl.value = saved;

function baseUrl() { return serverUrl.value.trim().replace(/\/$/, ''); }
function log(msg) { $('log').textContent = `[${new Date().toLocaleTimeString()}] ${msg}\n` + $('log').textContent; }
function setStatus(text, cls) { const p=$('statusPill'); p.textContent=text; p.className='status ' + (cls||''); }
function prettySize(bytes){ if(!bytes) return '0 B'; const u=['B','KB','MB','GB']; let i=0,n=bytes; while(n>1024&&i<u.length-1){n/=1024;i++;} return `${n.toFixed(i?1:0)} ${u[i]}`; }

$('saveBtn').onclick = () => { localStorage.setItem('serverUrl', baseUrl()); log('Server URL gemt.'); };

$('testBtn').onclick = async () => {
  try {
    const r = await fetch(`${baseUrl()}/health`);
    const j = await r.json();
    if (!j.ok) throw new Error('Server svarede, men ok=false');
    setStatus('Forbundet', 'ok');
    log(`Forbindelse OK: ${j.service} v${j.version || '?'}`);
  } catch (e) {
    setStatus('Fejl', 'bad');
    log('Forbindelse fejlede: ' + e.message);
  }
};

$('pickBtn').onclick = async () => {
  selectedFile = await window.pcApi.pickFile();
  $('pickedFile').textContent = selectedFile || 'Ingen fil valgt';
  if (selectedFile) log('Valgt fil: ' + selectedFile);
};

$('uploadBtn').onclick = async () => {
  try {
    if (!selectedFile) throw new Error('Vælg en fil først');
    log('Uploader...');
    const res = await window.pcApi.uploadFile(baseUrl(), selectedFile);
    log('Upload OK: ' + res.file.storedName);
    await loadFiles();
  } catch (e) { log('Upload fejl: ' + e.message); }
};

async function loadFiles(){
  try {
    const r = await fetch(`${baseUrl()}/api/files`);
    const j = await r.json();
    if (!j.ok) throw new Error(j.error || 'Kunne ikke hente filliste');
    $('files').innerHTML = '';
    if (!j.files.length) $('files').textContent = 'Ingen filer endnu.';
    j.files.forEach(f => {
      const div = document.createElement('div');
      div.className = 'fileitem';
      div.innerHTML = `<div><strong>${f.name}</strong><small>${prettySize(f.size)} · ${new Date(f.modified).toLocaleString()}</small></div>`;
      const btn = document.createElement('button');
      btn.textContent = 'Download';
      btn.onclick = async () => {
        try { const p = await window.pcApi.downloadFile(baseUrl(), f.name); log('Downloadet til: ' + p); }
        catch(e){ log('Download fejl: ' + e.message); }
      };
      div.appendChild(btn);
      $('files').appendChild(div);
    });
    log(`Filliste hentet: ${j.count} filer`);
  } catch(e) { log('Filliste fejl: ' + e.message); }
}

$('listBtn').onclick = loadFiles;
$('openDownloadsBtn').onclick = () => window.pcApi.openDownloads();
log('Klar. Indsæt Railway URL eller test lokalt med http://localhost:3000');
