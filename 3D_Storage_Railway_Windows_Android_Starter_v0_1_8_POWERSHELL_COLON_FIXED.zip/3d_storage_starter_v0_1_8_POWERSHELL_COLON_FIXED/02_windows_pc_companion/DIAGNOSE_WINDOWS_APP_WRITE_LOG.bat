@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set LOG=%~dp0windows_app_debug_log.txt
(
  echo ==================================================
  echo 3D Storage PC Companion - diagnose log
  echo Date: %DATE% %TIME%
  echo Folder: %CD%
  echo ==================================================
  echo.
  echo --- where node ---
  where node
  echo errorlevel=%ERRORLEVEL%
  echo.
  echo --- node -v ---
  node -v
  echo errorlevel=%ERRORLEVEL%
  echo.
  echo --- where npm ---
  where npm
  echo errorlevel=%ERRORLEVEL%
  echo.
  echo --- npm -v ---
  npm -v
  echo errorlevel=%ERRORLEVEL%
  echo.
  echo --- package.json exists ---
  if exist package.json (echo yes) else (echo no)
  echo.
  echo --- npm install ---
  call npm install --no-audit --no-fund
  echo npm install errorlevel=%ERRORLEVEL%
  echo.
  echo --- npm start ---
  call npm start
  echo npm start errorlevel=%ERRORLEVEL%
  echo.
  echo End: %DATE% %TIME%
) > "%LOG%" 2>&1

echo Debug log saved here:
echo %LOG%
echo.
echo Open this file and copy the text to ChatGPT:
echo windows_app_debug_log.txt
echo.
pause
