const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('pcApi', {
  pickFile: () => ipcRenderer.invoke('pick-file'),
  uploadFile: (serverUrl, filePath) => ipcRenderer.invoke('upload-file', serverUrl, filePath),
  downloadFile: (serverUrl, fileName) => ipcRenderer.invoke('download-file', serverUrl, fileName),
  openDownloads: () => ipcRenderer.invoke('open-downloads')
});
