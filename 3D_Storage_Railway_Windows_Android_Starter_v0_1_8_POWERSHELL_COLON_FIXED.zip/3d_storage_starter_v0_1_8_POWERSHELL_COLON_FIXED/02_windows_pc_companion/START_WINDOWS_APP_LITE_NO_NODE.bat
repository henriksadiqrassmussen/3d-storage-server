@echo off
chcp 65001 >nul
title 3D Storage PC Companion Lite
cd /d "%~dp0"
echo ==================================================
echo 3D Storage PC Companion Lite
echo ==================================================
echo.
echo Denne version bruger Windows PowerShell.
echo Den kraever IKKE npm, Node.js eller Electron.
echo.
echo Hvis Windows spoerger om tilladelse, vaelg Ja.
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0PC_COMPANION_LITE_POWERSHELL.ps1"
echo.
echo Appen er lukket.
echo Tryk en tast for at lukke dette vindue.
pause >nul
