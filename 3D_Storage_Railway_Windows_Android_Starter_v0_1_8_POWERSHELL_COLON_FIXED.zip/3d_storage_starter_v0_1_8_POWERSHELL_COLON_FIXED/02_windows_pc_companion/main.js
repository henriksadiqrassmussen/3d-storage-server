const { app, BrowserWindow, ipcMain, dialog, shell } = require('electron');
const path = require('path');
const fs = require('fs');

const downloadsDir = path.join(__dirname, 'downloads');
fs.mkdirSync(downloadsDir, { recursive: true });

function createWindow() {
  const win = new BrowserWindow({
    width: 1040,
    height: 760,
    minWidth: 900,
    minHeight: 650,
    title: '3D Storage PC Companion',
    backgroundColor: '#0f131a',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false
    }
  });
  win.loadFile('renderer.html');
}

app.whenReady().then(createWindow);
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });

ipcMain.handle('pick-file', async () => {
  const result = await dialog.showOpenDialog({
    properties: ['openFile'],
    filters: [
      { name: '3D files and ZIP', extensions: ['fbx', 'glb', 'gltf', 'zip'] },
      { name: 'All files', extensions: ['*'] }
    ]
  });
  if (result.canceled || !result.filePaths[0]) return null;
  return result.filePaths[0];
});

ipcMain.handle('upload-file', async (event, serverUrl, filePath) => {
  const base = String(serverUrl || '').replace(/\/$/, '');
  if (!base) throw new Error('Server URL mangler');
  if (!filePath || !fs.existsSync(filePath)) throw new Error('Filen findes ikke');

  const form = new FormData();
  const buffer = fs.readFileSync(filePath);
  const blob = new Blob([buffer]);
  form.append('file', blob, path.basename(filePath));

  const response = await fetch(`${base}/api/upload`, { method: 'POST', body: form });
  const text = await response.text();
  let json;
  try { json = JSON.parse(text); } catch { json = { ok: false, raw: text }; }
  if (!response.ok) throw new Error(json.error || text || `HTTP ${response.status}`);
  return json;
});

ipcMain.handle('download-file', async (event, serverUrl, fileName) => {
  const base = String(serverUrl || '').replace(/\/$/, '');
  const url = `${base}/files/${encodeURIComponent(fileName)}`;
  const response = await fetch(url);
  if (!response.ok) throw new Error(`Download fejl HTTP ${response.status}`);
  const arrayBuffer = await response.arrayBuffer();
  const target = path.join(downloadsDir, fileName);
  fs.writeFileSync(target, Buffer.from(arrayBuffer));
  return target;
});

ipcMain.handle('open-downloads', async () => {
  fs.mkdirSync(downloadsDir, { recursive: true });
  await shell.openPath(downloadsDir);
});
