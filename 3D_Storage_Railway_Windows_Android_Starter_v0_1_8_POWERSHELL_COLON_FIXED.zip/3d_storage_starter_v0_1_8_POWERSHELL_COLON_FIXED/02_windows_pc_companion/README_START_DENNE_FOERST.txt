START DENNE FØRST:

START_WINDOWS_APP_LITE_NO_NODE.bat

Denne version bruger Windows PowerShell og kræver ikke Node.js, npm eller Electron.
Den er lavet fordi .bat/Electron-versionen lukkede for hurtigt på nogle Windows-installationer.

Brug server URL:
- Lokal test: http://localhost:3000
- Railway: https://dit-railway-link.up.railway.app

Knapper:
1. Test forbindelse
2. Vælg FBX / GLB / ZIP
3. Upload til server
4. Hent filliste
