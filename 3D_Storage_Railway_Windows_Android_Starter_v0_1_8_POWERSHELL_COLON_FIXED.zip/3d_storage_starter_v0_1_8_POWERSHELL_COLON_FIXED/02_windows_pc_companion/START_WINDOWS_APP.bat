@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title 3D Storage PC Companion - NoClose
cls
echo ==================================================
echo  3D Storage PC Companion - Windows app
echo ==================================================
echo Mappe: %CD%
echo.

echo Tjekker Node.js...
where node
if errorlevel 1 goto NODE_MISSING
node -v

echo.
echo Tjekker npm...
where npm
if errorlevel 1 goto NPM_MISSING
npm -v

echo.
if not exist package.json goto PACKAGE_MISSING

echo Installerer/opdaterer pakker...
call npm install --no-audit --no-fund
if errorlevel 1 goto NPM_INSTALL_FAILED

echo.
echo Starter Windows app...
call npm start

echo.
echo Programmet stoppede eller lukkede. Se tekst ovenfor.
goto END

:NODE_MISSING
echo FEJL: Node.js mangler eller ligger ikke i PATH.
echo Installer Node.js LTS fra nodejs.org og genstart PC'en.
goto END

:NPM_MISSING
echo FEJL: npm blev ikke fundet. Installer Node.js LTS igen.
goto END

:PACKAGE_MISSING
echo FEJL: package.json findes ikke i denne mappe.
echo Pak ZIP'en ud og koer denne fil fra 02_windows_pc_companion.
goto END

:NPM_INSTALL_FAILED
echo FEJL: npm install fejlede. Kopier teksten ovenfor og send den til ChatGPT.
goto END

:END
echo.
echo Tryk en tast for at lukke dette vindue...
pause >nul
