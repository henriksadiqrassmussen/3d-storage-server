WINDOWS-APPEN FINDES HER
========================

Denne mappe er Windows makker-appen:
02_windows_pc_companion

Start i denne rækkefølge:

1) Dobbeltklik:
   START_WINDOWS_APP_SAFE_CMDK.bat

Denne åbner et ekstra sort vindue, som IKKE lukker automatisk.
Hvis der er fejl, bliver teksten stående.

2) Hvis den stadig lukker eller du ikke kan nå at se noget:
   DIAGNOSE_WINDOWS_APP_WRITE_LOG.bat

Den laver filen:
   windows_app_debug_log.txt

Kopier teksten fra den fil og send den til ChatGPT.

3) Alternativ start:
   START_WINDOWS_APP_POWERSHELL_SAFE.bat

KRÆVER
======
Node.js LTS installeret.
Efter installation af Node.js: genstart PC'en eller åbn en ny .bat.

VIGTIGT
=======
Kør ikke filerne inde fra ZIP'en. Pak ZIP'en ud først, fx til:
C:\3D_Storage_Test\
