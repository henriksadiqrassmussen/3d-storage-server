ANDROID APP -> SERVER -> WINDOWS APP TEST
=========================================

Status:
- Lokal Windows app virker mod http://localhost:3000/health
- Denne v0.1.8 server lytter nu på hele Wi-Fi-netværket, ikke kun localhost.

TRIN 1 - Start serveren på PC
-----------------------------
Dobbeltklik:
START_HER_SERVER_LITE_NO_NODE.bat

Server-vinduet viser fx:
http://192.168.1.25:3000

Det er denne adresse Android-appen skal bruge.
Telefon og PC skal være på samme Wi-Fi.

TRIN 2 - Test fra Windows app
-----------------------------
Dobbeltklik:
START_HER_WINDOWS_APP_LITE.bat

Skriv:
http://localhost:3000

Tryk Test forbindelse.
Hvis OK, er serveren klar.

TRIN 3 - Test fra Android app
-----------------------------
Byg Android appen i Android Studio fra mappen:
03_android_apk_app

I appens serverfelt skriver du PC-adressen fra server-vinduet, fx:
http://192.168.1.25:3000

Vælg en lille .glb/.fbx/.zip fil.
Tryk Upload til 3D Storage.

TRIN 4 - Se filen i Windows app
-------------------------------
Gå tilbage til Windows appen.
Skriv stadig:
http://localhost:3000

Tryk Hent filliste.
Nu skal Android-filen vises.

Hvis Android ikke forbinder
---------------------------
1. Tjek at telefon og PC er på samme Wi-Fi.
2. Brug IKKE http://localhost:3000 på Android. Localhost på telefonen er telefonen selv.
3. Brug PC IP: http://192.168.x.x:3000
4. Tillad PowerShell/port 3000 i Windows Firewall på Privat netværk.
5. Prøv at åbne http://PC-IP:3000/health i telefonens browser.
