START SERVER FOERST

1. Pak ZIP helt ud paa Skrivebordet.
2. Kør fra hovedmappen:
   START_HER_SERVER_LITE_NO_NODE.bat

Hvis du står inde i 01_railway_server-mappen, kan du også køre:
   START_LOCAL_SERVER_LITE_NO_NODE.bat

Rettet i v0.1.6:
- Startfilen peger ikke længere på 01_railway_server\01_railway_server.
- Den bruger absolut sti fra .bat-filens egen mappe.
- Hvis scriptet mangler, vises den præcise sti i vinduet.
