@echo off
cd /d "%~dp0\02_windows_pc_companion"
call START_WINDOWS_APP_SAFE_CMDK.bat
