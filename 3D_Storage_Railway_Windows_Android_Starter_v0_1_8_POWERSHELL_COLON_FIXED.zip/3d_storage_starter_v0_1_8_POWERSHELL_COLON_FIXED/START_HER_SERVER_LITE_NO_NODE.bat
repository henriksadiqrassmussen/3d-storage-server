@echo off
setlocal
set "ROOT=%~dp0"
set "SERVER=%ROOT%01_railway_server"
if not exist "%SERVER%\LOCAL_SERVER_LITE_NO_NODE.ps1" (
  echo FEJL: Kan ikke finde server script.
  echo ROOT: %ROOT%
  echo SERVER: %SERVER%
  echo Forsoegte: %SERVER%\LOCAL_SERVER_LITE_NO_NODE.ps1
  echo.
  echo Pak ZIP ud igen og koer denne fil fra hovedmappen.
  echo.
  pause
  exit /b 1
)
cd /d "%SERVER%"
call "%SERVER%\START_LOCAL_SERVER_LITE_NO_NODE.bat"
