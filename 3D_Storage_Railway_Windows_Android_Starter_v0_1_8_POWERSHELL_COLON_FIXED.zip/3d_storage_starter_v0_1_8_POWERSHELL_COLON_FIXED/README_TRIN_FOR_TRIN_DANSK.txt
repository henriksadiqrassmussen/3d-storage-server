3D Storage Starter v0.1.8 - Android til PC flow
===============================================

Målet i denne version:
Android app -> lokal server på PC -> Windows app kan se fillisten.

1) Start lokal server:
   START_HER_SERVER_LITE_NO_NODE.bat

2) Kig i server-vinduet. Det viser både:
   http://localhost:3000
   og en Wi-Fi adresse som fx http://192.168.1.25:3000

3) Start Windows app:
   START_HER_WINDOWS_APP_LITE.bat
   Brug http://localhost:3000 og tryk Test forbindelse.

4) Start Android appen.
   Brug PC Wi-Fi adressen, fx http://192.168.1.25:3000
   Upload en .glb/.fbx/.zip fil.

5) I Windows appen trykker du Hent filliste.
   Filen fra Android skal nu vises.

Læs også:
README_ANDROID_TIL_WINDOWS_TEST.txt
