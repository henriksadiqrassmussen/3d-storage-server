@echo off
set "SERVER_DIR=%~dp0"
cmd /k "cd /d "%SERVER_DIR%" && echo 3D Storage ULTRA SAFE SERVER START && echo. && echo Script: "%SERVER_DIR%LOCAL_SERVER_LITE_NO_NODE.ps1" && echo. && powershell -NoProfile -ExecutionPolicy Bypass -File "%SERVER_DIR%LOCAL_SERVER_LITE_NO_NODE.ps1" && echo. && echo STOPPET - vinduet bliver aabent"
