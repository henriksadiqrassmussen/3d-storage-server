@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title 3D Storage Local Server - DEBUG
cls
echo ==================================================
echo  3D Storage Local Server - NoClose / Debug
echo ==================================================
echo Mappe: %CD%
echo.

echo Tjekker Node.js...
where node >nul 2>nul
if errorlevel 1 (
  echo FEJL: Node.js er ikke installeret eller ligger ikke i PATH.
  echo.
  echo Loesning:
  echo 1. Installer Node.js LTS fra https://nodejs.org
  echo 2. Luk dette vindue
  echo 3. Aabn en NY kommandoprompt eller genstart PC
  echo 4. Koer denne .bat igen
  echo.
  pause
  exit /b 1
)
node -v

echo.
echo Tjekker npm...
where npm >nul 2>nul
if errorlevel 1 (
  echo FEJL: npm blev ikke fundet.
  echo Installer Node.js LTS og proev igen.
  echo.
  pause
  exit /b 1
)
npm -v

echo.
if not exist package.json (
  echo FEJL: package.json findes ikke i denne mappe.
  echo Du skal koere filen inde fra 01_railway_server-mappen.
  echo.
  pause
  exit /b 1
)

if not exist node_modules (
  echo Installerer server-pakker foerste gang...
  call npm install
  if errorlevel 1 (
    echo.
    echo FEJL: npm install fejlede.
    echo Kopier fejlteksten herfra og send den til ChatGPT.
    echo.
    pause
    exit /b 1
  )
) else (
  echo node_modules findes allerede - springer install over.
)

echo.
echo Starter server paa http://localhost:3000
echo Stop serveren med CTRL+C.
echo.
call npm start

echo.
echo Programmet stoppede. Se fejl ovenfor hvis noget gik galt.
pause
