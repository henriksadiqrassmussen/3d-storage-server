@echo off
setlocal
set "SERVER_DIR=%~dp0"
cd /d "%SERVER_DIR%"
title 3D Storage Local Server Lite - NO NODE
cls
echo ==================================================
echo  3D Storage Local Server Lite - NO NODE
echo ==================================================
echo Denne server kraever IKKE Node.js, npm eller Electron.
echo Den bruger Windows PowerShell.
echo.
echo Mappe: %CD%
echo Script: %SERVER_DIR%LOCAL_SERVER_LITE_NO_NODE.ps1
echo.
if not exist "%SERVER_DIR%LOCAL_SERVER_LITE_NO_NODE.ps1" (
  echo FEJL: LOCAL_SERVER_LITE_NO_NODE.ps1 findes ikke.
  echo Forsoegte: %SERVER_DIR%LOCAL_SERVER_LITE_NO_NODE.ps1
  echo.
  pause
  exit /b 1
)
echo Starter PowerShell-server...
echo Vinduet skal blive aabent. Stop med CTRL+C.
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%SERVER_DIR%LOCAL_SERVER_LITE_NO_NODE.ps1"
echo.
echo Serveren stoppede.
echo.
pause
