@echo off
cls
echo ==================================================
echo  3D Storage - Start Menu
 echo ==================================================
echo.
echo 1 = Start lokal Railway/server test
echo 2 = Start Windows PC Companion
echo.
set /p valg=Vaelg 1 eller 2 og tryk ENTER: 
if "%valg%"=="1" (
  cd /d "%~dp001_railway_server"
  call START_LOCAL_SERVER_DEBUG_NOCLOSE.bat
  exit /b
)
if "%valg%"=="2" (
  cd /d "%~dp002_windows_pc_companion"
  call START_WINDOWS_APP_DEBUG_NOCLOSE.bat
  exit /b
)
echo Ugyldigt valg.
pause
